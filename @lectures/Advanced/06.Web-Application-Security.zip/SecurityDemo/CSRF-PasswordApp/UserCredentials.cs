﻿namespace CSRF_PasswordApp
{
    public static class UserCredentials
    {
        public static string Username = "guest";

        public static string Password = "guest123";
    }
}
